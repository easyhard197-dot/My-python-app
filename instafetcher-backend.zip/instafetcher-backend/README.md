# InstaFetcher X — Backend (Vercel)

Apna khud ka Instagram downloader API — `rydenxgod.workers.dev` pe depend nahi karna padega.

## Deploy on Vercel (2 min)

1. Iss folder ko GitHub pe push karo (ya direct Vercel CLI se deploy karo).
2. [vercel.com](https://vercel.com) pe jao → **Add New Project** → apna repo select karo.
3. Vercel khud detect kar lega ki ye Python project hai (`vercel.json` already configured hai). Deploy dabao.
4. Deploy hone ke baad tujhe ek URL milega, jaise:
   ```
   https://your-project.vercel.app
   ```

### CLI se deploy (alternative)
```bash
npm i -g vercel
cd instafetcher-backend
vercel --prod
```

## Test karo
Deploy hone ke baad browser mein ya curl se check karo:
```
https://your-project.vercel.app/?url=https://www.instagram.com/reel/SOME_REEL_ID/
```
Response aana chahiye:
```json
{ "status": "success", "video": "https://...", "thumbnail": "https://..." }
```

## Frontend (index.html) mein change karo

`index.html` ke `<script>` section mein ye line dhundo:
```js
const apiURL = `https://instadl.rydenxgod.workers.dev/?url=${encodeURIComponent(url)}`;
```
Isse apne naye Vercel URL se replace karo:
```js
const apiURL = `https://your-project.vercel.app/?url=${encodeURIComponent(url)}`;
```

Bas itna hi — ab tera downloader tere khud ke backend pe chalega.

## Limitations (jaan lena zaroori)

- **Private posts / login-required reels** kaam nahi karenge — Instagram unke liye login maangta hai, aur yeh API anonymous hai (jaise original wala bhi tha).
- **Photo-only posts** is version mein video nahi return karenge (sirf video/reel support hai abhi).
- Vercel ke **free (Hobby) plan** mein function timeout 10 seconds hai — zyadatar reels isi mein fetch ho jaate hain, lekin agar Instagram slow respond kare to kabhi-kabhi timeout ho sakta hai.
- Instagram apna page structure/blocking kabhi-kabhi badalta rehta hai — agar future mein errors aane lagein, to `yt-dlp` ko update karna padega (`pip install -U yt-dlp` locally test karne ke liye, aur Vercel pe redeploy).
